package app.audio;

import java.util.*;
import app.util.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;


public class AudioTaskDao {
  private static AudioTask currentTask;
	private List<AudioTask> audioTasks = new LinkedList<AudioTask>();
	
	public AudioTaskDao() {
    	Session session = HibernateUtil.currentSession();
   		audioTasks = session.createCriteria(AudioTask.class).list();
    	session.close();
  }

	public void setRandomTask(){
    	currentTask = audioTasks.get(new Random().nextInt(audioTasks.size()));
	}

  public List<AudioFile> getCurrentTaskFiles() {
      List<AudioFile> taskFiles = new ArrayList<AudioFile>();
      //System.out.println("Current Task : " + currentTask.getTaskID());
      Session session = HibernateUtil.currentSession();
      session.beginTransaction();
      
      System.out.println(currentTask.getName() +
        " is the task for " + currentTask.getDescription() +
        " and contains the files");
        for (AudioFile file : currentTask.getFiles()) {
        System.out.println("  " + file.getFilePath());
        }
      
      session.close();
     
      taskFiles.addAll(currentTask.getFiles());
      return taskFiles;
  }
}
