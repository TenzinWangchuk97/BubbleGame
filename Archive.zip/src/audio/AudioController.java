package app.audio;

import app.util.*;
import app.user.*;
import spark.*;
import java.util.*;
import java.io.*;
import java.net.*;
import static app.Application.audioFileDao;
import static app.Application.audioTaskDao;
import static app.Application.userDao;
import static app.util.ContextUtil.*;
import org.apache.commons.io.IOUtils;

public class AudioController {	
	private static int num_choices = 6;		//Number of choices for each round

	public static Route fetchRandomAudioFiles = (Request request, Response response) -> {	//Function called when the user starts first round
		
		if(request.cookie("guide") == null) {
				response.redirect(getContextPath(request) + Path.Web.GUIDE);
				return null;
		}

		HashMap<String, Object> model = new HashMap<>();
		audioTaskDao.setRandomTask();
		HashMap<String, String> randomFileMap = getRandomFiles();

		String username = request.session().attribute("currentUser");
		if(username == null) 
			username = "guest";
		
		model.put("speechFile", randomFileMap.get("speechFile"));
		model.put("noiseFile", randomFileMap.get("noiseFile"));
		model.put("choices", randomFileMap.get("choices"));
		model.put("username", username);
		
		return ViewUtil.render(request, model, Path.Template.GAME);
    };
	
	public static Route handleAudioPost = (Request request, Response response) -> {	//Function called when the user continues to the next round
		HashMap<String, Object> request_body = JsonUtil.parse(request.body());

		String username = request_body.get("username").toString();
		if(!username.equals("guest")) {
			String scoreString= request_body.get("pointsScored").toString();
			int parsedScore = Integer.parseInt(scoreString.substring(0, scoreString.length() - 2));
			userDao.updateTotalScore(username, parsedScore);
		}
		

		if(request_body.get("messageType").equals("continue")) {
			HashMap<String, Object> model = new HashMap<>();
			HashMap<String, String> randomFileMap = getRandomFiles();
			
			model.put("speechFile", randomFileMap.get("speechFile"));
			model.put("noiseFile", randomFileMap.get("noiseFile"));
			model.put("choices", randomFileMap.get("choices"));
			model.put("username", request.session().attribute("currentUser"));
			
			return model;
		}

		return null;
    };
	
	public static HashMap<String, String> getRandomFiles() {
        HashMap<String, String> map = new HashMap<String,String>();
		List<AudioFile> list = audioFileDao.getAudioFiles();
		List<AudioFile> taskFiles = audioTaskDao.getCurrentTaskFiles();
        AudioFile speechFile = taskFiles.get(new Random().nextInt(taskFiles.size()));	
		AudioFile noiseFile = audioFileDao.getRandomNoiseFile();						
		HashMap<String, Integer> map_of_choices = new HashMap<String, Integer>(); 				
		
		String speechChoice = speechFile.getCorrectResponse();
		map_of_choices.put(speechChoice, 0);									
				
		String choices = "";													
		choices += speechChoice + " ";											
										
		int choices_count = num_choices;											
	
		while(choices_count > 1) {
			AudioFile choiceFile = taskFiles.get(new Random().nextInt(taskFiles.size()-1));
			String choice = choiceFile.getCorrectResponse();
			
			if(!(map_of_choices.containsKey(choice))) { 
				map_of_choices.put(choice, 0);
				choices += choice + " ";
				choices_count --;
			}
		} choices = choices.substring(0, choices.length() - 1);	//Remove last space

		map.put("speechFile", speechFile.getFilePath());
		map.put("noiseFile", noiseFile.getFilePath());
		map.put("choices", choices);
		return map;
	}

	public static File getFileURL(String url) throws MalformedURLException, IOException {
	    BufferedInputStream in = null;
	    FileOutputStream fout = null;
	    final byte data[] = new byte[1024];
	    File outputFile = new File("acha_w3_01_03.wav");

	    try {
	        in = new BufferedInputStream(new URL("http://m.mr-pc.org/bubblesGame/acha_w3_01_03.wav").openStream());
	        fout = new FileOutputStream(outputFile);

	        int count;
	        while ((count = in.read(data, 0, 1024)) != -1) {
	            fout.write(data, 0, count);
	        }
	    } finally {
	        if (in != null) {
	            in.close();
	        }
	        if (fout != null) {
	            fout.close();
	        }
	    }
	    return outputFile;
	}	

}


