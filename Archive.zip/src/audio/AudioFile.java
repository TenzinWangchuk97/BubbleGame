package app.audio;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GenerationType;
import java.util.Set;
import java.util.HashSet;
import javax.persistence.ManyToMany;

@Entity
@Table(name = "AudioFiles")
public class AudioFile implements Comparable<AudioFile> {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "fileID")
    private int fileID;
    private String filePath;
    private String correctResponse;

    @ManyToMany(mappedBy="files")
    private Set<AudioTask> tasks = new HashSet<AudioTask>();
	
    public AudioFile() {}

	public AudioFile(int fileID, String filePath, String correctResponse) {
		this.filePath = filePath;
        this.correctResponse = correctResponse;
	}
	
    public Set<AudioTask> getTasks() {
        return tasks;
    }

    public void setFileID(int fileID) {
        this.fileID = fileID;
    }

    public int getFileID() {
        return fileID;
    }

    public void setFilePath(String filePath){
        this.filePath = filePath;
    }

    public String getFilePath() {
       return filePath;
    }
	
    public void setCorrectResponse(String correctResponse) {
        this.correctResponse = correctResponse;
    }

    public String getCorrectResponse() {
        return correctResponse;
    }

	@Override
    public int compareTo(AudioFile o) {
        return this.filePath.compareTo(o.getFilePath()); 
    }

    @Override
    public String toString() {
        return this.filePath;
    }
}
