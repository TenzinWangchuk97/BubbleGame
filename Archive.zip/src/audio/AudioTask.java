package app.audio;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import java.util.Set;
import java.util.HashSet;
import javax.persistence.ManyToMany;

@Entity
@Table(name = "AudioTasks")
public class AudioTask {
    @Id
    @Column(name = "taskID")
    private int taskID;
    private String name;
    private String description;
	
    @ManyToMany
    @JoinTable (
        name = "TaskFiles",
        joinColumns = {@JoinColumn(name="taskID")},
        inverseJoinColumns={@JoinColumn(name="fileID")}
    )
    private Set<AudioFile> files = new HashSet<AudioFile>();

    public AudioTask() {}

	public AudioTask(int taskID, String name, String description) {
		this.taskID = taskID;
        this.name = name;
        this.description = description;
	}
	
    public void addFile(AudioFile file) {
        this.files.add(file);
        file.getTasks().add(this);
    }

    public Set<AudioFile> getFiles() {
        return files;
    }

    public void setTaskID(int taskID) {
        this.taskID = taskID;
    }

    public int getTaskID() {
        return taskID;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getName() {
       return name;
    }
	
    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

}
