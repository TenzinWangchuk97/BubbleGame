package app.audio;

import com.google.common.collect.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.util.Collections;
import java.util.stream.Collectors;
import app.util.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Query;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class AudioFileDao {
	private List<AudioFile> audioFiles;              //Stores list of audio files
    private HashMap<String, Integer> filePathMap;   //Stores list of filenames for quick lookup
    private final String relativePath = "/src/main/resources/public/aXaW3/";
	private final String classPath = "/public/aXaW3/";

	public AudioFileDao() { 
        audioFiles = new ArrayList<AudioFile>();
        filePathMap = new HashMap<String, Integer>();
        refreshList();
	}

    public void create(AudioFile audioFile) {    //Saves the audio file into the database
        Session session = HibernateUtil.currentSession();
        session.beginTransaction();
        session.save(audioFile);
        session.getTransaction().commit();
        session.close();
        refreshList();
    }
    
    public void refreshList() {     //Refrshes file list audio files from sql table
        Session session = HibernateUtil.currentSession();
        audioFiles = session.createCriteria(AudioFile.class).list();
        Collections.sort(audioFiles);
        session.close();
    }

    public void refreshList(String path) throws IOException {   //Refreshes file list and database with classpath files
        Session session = HibernateUtil.currentSession();
        audioFiles = session.createCriteria(AudioFile.class).list();
         
        for(AudioFile a: audioFiles) {
            filePathMap.put(a.getFilePath(), 0);   
            System.out.println(a.getFilePath());     
        }

		try {
            ResourceLoader loader = new ResourceLoader();
            ArrayList<String> localFileList = loader.getResourceFiles(path);
            
            for(String string: localFileList) {
                if(!filePathMap.containsKey(string)) //Prevents unique key duplication
                    create(new AudioFile(0, string, string.substring(0, string.indexOf('_'))));
            }

            Collections.sort(audioFiles);
        } catch(IOException e){
             System.out.println("General I/O exception: " + e.getMessage());
             e.printStackTrace();
        }

        session.close();
	}
	
	public List<AudioFile> getAudioFiles(){
	    refreshList();
        return audioFiles;
    }
	
    public Iterable<AudioFile> getAllAudioFiles() {
        return audioFiles;
    }
	
    public AudioFile getRandomNoiseFile() {
        List<AudioFile> noiseFiles = audioFiles.stream()                
            .filter(file -> file.getCorrectResponse().equals("noise"))    
            .collect(Collectors.toList());           
        return noiseFiles.get(new Random().nextInt(noiseFiles.size()));
    }

    public HashMap<String, Integer> getFilePathMap() {
        return filePathMap;
    }

	public void printAudioFileList() {
		System.out.println("Audio File List");
		for(AudioFile file: audioFiles) {
			System.out.println(file.getFilePath());		
		}	
	}

    public void printClassPath() {
        ClassLoader cl = ClassLoader.getSystemClassLoader();

        URL[] urls = ((URLClassLoader)cl).getURLs();
        System.out.println("Classpath: ");
        for(URL url: urls){
            System.out.println(url.getFile());
        }
    }
}
