/*
	The core of the auditory bubbles javascript code. This file contains all of the
	audio related functions and functions for the GUI. Currently the game states are
	decided under a switch statement. The next round function sends a json message
	to Spark in order to gain the required information to continue the game loop.

	*Functions that are used to load files locally are described are defined in json.js.
*/

//Once these are no longer null game loop starts real stuff
var sab; //speech audio buffer
var nab; //noise audio buffer
var snab;//shortened noise audio buffer
var random;
var guideMode;
var startDateTimeStamp;
var source;
var playing;
var playNext;
var playCount = 0;
//variables for GUI
var round_state;

function gameInit(){

    loadAudioFiles(start);

}

function adminInit (){

    loadAudioFiles(startInit);

}

function loadAudioFiles(callNext) {
	choices = server_choices.split(" ");
	
	var reader = new FileReader();
	var speech_loaded = false;
	
	getSpeechObject(speechFile, function (fileObject) {
		var speech_file = fileObject;
		reader.onloadend = function () {
			checkSpeechFile();
			speech_loaded = true;
			speechArrayBuffer = reader.result;
			
			context.decodeAudioData(speechArrayBuffer, function(buffer) {
				sab = buffer;
				if(nab!=null && sab!=null){
					callNext();//call argument
				}
			}, function(error){console.error("decodeAudioData" , error);});		
		}
		reader.readAsArrayBuffer(speech_file);
	}); 
	
	function checkSpeechFile() {
		if(speech_loaded){
			getNoiseObject(noiseFile, function (fileObject) {
				var noise_file = fileObject;
					
				reader.onloadend = function () {
					speechArrayBuffer = reader.result;
						
					context.decodeAudioData(speechArrayBuffer, function(buffer) { 
						nab = buffer;
						if(nab!=null && sab!=null){
							callNext();//call argument
						}	
					});
				}
				reader.readAsArrayBuffer(noise_file);
			});
		}
		
		else {
			setTimeout(function(){
				checkSpeechFile();
			},250);
		}
	}
}
//setTimeout(init, 100); //Do something about this later


//Intialize the variables for the round
function start(){
    var gameRemove = false;
	initChoices(); //Initialize the buttons
	setup();
	initScoring();
    initBlur(gameRemove);

}

//Initializes variables in order to draw admin image

function startInit(){

    var initRemove = true;
    imageInit();
    initBlur(initRemove);

}

//Intializes variables for the round
function setup(){
	//setup audiovariables
	snab = cutNoise(nab.getChannelData(0), sab.getChannelData(0).length);
	var mixed = mix(sab.getChannelData(0), snab.getChannelData(0))

	//setup html canvas variables
	var width = Math.ceil(sab.getChannelData(0).length/HOP); 
	canvas.width = width;
	canvas.height = SAMPLES/2 - clipY;
	total = width * (SAMPLES/2 - clipY);
	
	speechSpectrum = transform(sab.getChannelData(0))["spectrum"];
 	var tmap = transform(snab.getChannelData(0));
	noiseReal = tmap["real"];
	noiseImag = tmap["imag"];
	canvas.style.display = "none";	//Don't display the canvas yet
	draw(speechSpectrum);

	//setup variables for json message
	locationsUnblurred = new Set(); //Resets the unblurred locations to blurred
	startDateTimeStamp = new Date();

	//setup displ viarables
	document.getElementById("instructions").style.display = "none";
	round_state = document.getElementById("round_status");
	scoreboard = document.getElementById("bubblepoints");
	scoreboard.style.display = "initial";

	play(mixed);
}
function imageInit(){

    snab = cutNoise(nab.getChannelData(0), sab.getChannelData(0).length);
	var mixed = mix(sab.getChannelData(0), snab.getChannelData(0))

	//setup html canvas variables
	var width = Math.ceil(sab.getChannelData(0).length/HOP);
	canvas.width = width;
	canvas.height = SAMPLES/2 - clipY;
	total = width * (SAMPLES/2 - clipY);

	speechSpectrum = transform(sab.getChannelData(0))["spectrum"];
 	var tmap = transform(snab.getChannelData(0));
	noiseReal = tmap["real"];
	noiseImag = tmap["imag"];
	//canvas.style.display = "none";	//Don't display the canvas yet
	draw(speechSpectrum);

}

//Intializes variables for the next round and sends data to server
function nextRound() {
	//reset variables
	nab = null; 
	sab = null;
	choices = null;
	json = null;
	speechArrayBuffer = null;
	noiseArrayBuffer = null;
	scoreboard.style.display = "none";
	document.getElementById("instructions").style.display = "initial";
	gameInit();
}


function roundEnd() {
	updateScore();
	removeBlur();
	play(sab);
	disableStage();
	if(answered_correctly == true) updateRoundStatus("win");
		else updateRoundStatus("lose");

	sendServerInfo();
	//display the continue button
	setTimeout(nextRound, 1000) //wait ten seconds before continuing	
}

function sendServerInfo() {
	sendRoundInfo();
	sendUserInfo();
}

function sendRoundInfo() {
	//Updating info to send to database 
	var roundInfo = {}; //variable for adding updates info for every round to server
	roundInfo.username = userName;
	roundInfo.speechFile = speechFile;
	roundInfo.noiseFile = noiseFile;
	roundInfo.noiseFilePos = random;
	roundInfo.clickPos = [];
	roundInfo.choices = choices;
	roundInfo.wordGuessed = wordGuessed;
	roundInfo.pointsScored = pointsScored;

	//Collect the click positions
	for(var i = 0;i < click_positions.length;i++) 
		roundInfo.clickPos.push(click_positions[i]);

	//Date time stamp conversion to json
	var currentDateTimeStamp = new Date();
	roundInfo.dateTimeStamp = currentDateTimeStamp.toISOString().slice(0, 19).replace('T', ' ');

	roundInfo.elapsedTime = currentDateTimeStamp - startDateTimeStamp;
	//send info back to server 	
	var xhr = new XMLHttpRequest();
	xhr.open("POST", servletContext + "/update/", true);
	xhr.setRequestHeader('Content-Type', 'application/json');
	xhr.send(JSON.stringify(roundInfo));
}

function sendUserInfo() {
	//Updating info to send to database
	var jsonMessage = { "messageType" : "continue", "username" : userName, "pointsScored" : total_score };	//continue message
	var xhr = new XMLHttpRequest();
	xhr.open("POST", servletContext + "/game/", true);
	xhr.setRequestHeader('Content-Type', 'application/json');
	
	//Catches the response and sends it to handler fucntion. Calls for new round.
	xhr.onload = function () { 							
		var responseText = this.responseText;
		handleResponse(responseText);								
	}
	xhr.send(JSON.stringify(jsonMessage));	
}

//plays sample buffer and updates the round status
function play(buf) {
	if(source != null && !source.paused) {
		playNext = buf;
		checkBubblePoints();
	}

	else {
		disableButtons();

	    // Create a source node from the buffer
	    source = context.createBufferSource();
	    source.buffer = buf;
	    // Connect to the final output node (the speakers)
	    source.connect(context.destination);
	    // Play immediately
	    source.start(0);
	
		source.onended = function () {
			source = null;

			if(!answered_yet) {
			
				if(playNext != null) {
					play(playNext);
					playNext = null;
				}

				else {
					enableStage();
					enableButtons();
					checkBubblePoints();
					updateRoundStatus("selecting");
				}
			}
		}
	}
}

function displayInfo() {
	console.log("New Round");
	console.log("user: " + userName);
	console.log("choices: " + server_choices);
    console.log("speech file: " + speechFile);
	console.log("noise file: " + noiseFile); 
	console.log("canvas is " + canvas.width + " by " + canvas.height);
}

var gameStates = {
    'selecting': "Which Word Did You Hear?",
    'playing': "Playing Spectrogram . . .",
    'win': "Correct!",
    'lose': "Incorrect",
}

//Updates the round state on the main page
function updateRoundStatus(stateKey) {
	round_state.innerHTML = gameStates[stateKey];
}
