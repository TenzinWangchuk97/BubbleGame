/*
FUNCTIONS FOR BLUR:
*/

var canvas = document.getElementById("canvas");	//Stores the DOM canvas
var stage;				//Easel stage
var drawing_canvas;		//Easel drawing canvas
var blur;				//Easel blur
var cursor;				//The stage cursor represented by a white ellipse
var image;				//Stores the image of spectrogram on canvas
var bitmap;				//Easel bitmap 
var maskFilter;			//Easel alpha mask filter
var is_drawing; 		//boolean value for whether or not blur is drawing
var radius = 15; 		//radius of the cursor(ellipse)
var scale;				//keeps track of the scale of the cursor along the y-axis
var clipY = 200;		//How far down the spectrogram is moved downwards
var can_draw; 			//boolean value for whether or not image can be blurred
var can_deduct;			//boolean value for whether or not bubble_points can be deducted
var copy_image;

function initBlur() {
	stage = new createjs.Stage("canvas");
    image = new Image();
	image.src = canvas.toDataURL();
    image.onload = handleComplete;
}

//Initiates the stage, cursor and the blur
function handleComplete() {
    stage.enableMouseOver();
    stage.addEventListener("stagemousemove", handleMouseMove);
    stage.addEventListener("stagemousedown", handleMouseDown);
    stage.addEventListener("stagemouseup", handleMouseUp);
    drawing_canvas = new createjs.Shape();

    bitmap = new createjs.Bitmap(image);
    copy_image =  new createjs.Bitmap(image);
 
	blur = new createjs.Bitmap(image);
	blur.filters = [new createjs.BlurFilter(20, 20, 20), new createjs.ColorMatrixFilter(new createjs.ColorMatrix().adjustSaturation(-100))];
    blur.cache(0, 0, canvas.width, canvas.height);
  
    stage.addChild(blur, bitmap);	
    updateCacheImage(false);
 	
    cursor = new createjs.Shape(new createjs.Graphics().beginFill("#FFFFFF").drawCircle(0, 0, radius));
    cursor.cursor = "pointer";
  
    stage.addChild(cursor);
    stage.update();
    
	canvas.style.display = "initial";
	focusStage();
}

//Checks to see whether or not the mouse is on the stage
function handleMouseDown(event) {
	if(stage.mouseInBounds && can_draw)
		is_drawing = true;
}

//Removes the blur and updates noise and score
function handleMouseUp(event) {
	if(is_drawing){
		cursor.visible = false;	//Hides the cursor when blur is removed
		var midPoint = new createjs.Point(stage.mouseX, stage.mouseY);
	    drawing_canvas.graphics.setStrokeStyle(1, "round", "round")
		  .beginFill("rgba(0,0,0,1)")
		  .drawEllipse(stage.mouseX-radius, stage.mouseY - radius*scale, radius*2, radius*2*scale); 
	
      	updateCacheImage(true);
      	var buffer = updateNoise(parseInt(stage.mouseX), parseInt(stage.mouseY+clipY), radius, parseInt(radius*scale*-1));
		play(buffer);
		is_drawing = false;
	}	
}

//Updates the size of the cursor based on the position of the mouse
function handleMouseMove(event) {
	cursor.x = stage.mouseX;
	cursor.y = stage.mouseY;
	scale = (stage.mouseY - canvas.height*2)/canvas.height;
	cursor.scaleY = scale;
	
	if(!is_drawing) {
		stage.update();
		return;
	}
	
	updateCacheImage(true);
}

function removeBlur() {	//Removes blur
	stage.removeAllChildren();
	stage.addChild(copy_image);
	stage.update();
}

function updateCacheImage(update) {	//Updates the blur
	if (update) {
	  drawing_canvas.updateCache();
	} 
	
	else {
		drawing_canvas.cache(0, 0, image.width, image.height);
	}

	maskFilter = new createjs.AlphaMaskFilter(drawing_canvas.cacheCanvas);

	bitmap.filters = [maskFilter];
    if (update) {
	 	  bitmap.updateCache(0, 0, image.width, image.height);
	} 
	
	else {
		bitmap.cache(0, 0, image.width, image.height);
	}
 	stage.update();
}


function disableStage() {
	can_draw = false;
}

function enableStage() {
	can_draw = true;
	cursor.visible = true;
}

function focusStage() {
	window.location.hash = '#stage';
	console.log("focus stage");
}