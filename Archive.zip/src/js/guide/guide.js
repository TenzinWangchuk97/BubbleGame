//Once these are no longer null game loop starts real stuff
var sab; //speech audio buffer
var nab; //noise audio buffer
var snab;//shortened noise audio buffer
var speechArrayBuffer, noiseArrayBuffer = null;
var context = new AudioContext;

var speechFile;
var noiseFile;
var guideMode;


function init() {
	console.log("Auditory Bubbles Guide");
	
	speechFile = "http://m.auditorybubbles.com/acha_w3_01_03.wav";
	noiseFile = "http://m.auditorybubbles.com/noise_aXaW3.wav";
	var reader = new FileReader();
	var speech_loaded = false;
	
	getSpeechObject(speechFile, function (fileObject) {
		var speech_file = fileObject;
			
		reader.onloadend = function () {
			checkSpeechFile();
			speech_loaded = true;
			speechArrayBuffer = reader.result;
			
			context.decodeAudioData(speechArrayBuffer, function(buffer) { 
				sab = buffer;
				if(nab!=null && sab!=null){
					start();
				}
			}, function(error){console.error("decodeAudioData" , error);});		
		}
		reader.readAsArrayBuffer(speech_file);
	}); 
	
	function checkSpeechFile() {
		if(speech_loaded){
			getNoiseObject(noiseFile, function (fileObject) {
				var noise_file = fileObject;
					
				reader.onloadend = function () {
					speechArrayBuffer = reader.result;
						
					context.decodeAudioData(speechArrayBuffer, function(buffer) { 
						nab = buffer;
						if(nab!=null && sab!=null){
							start();	
						}	
					});
				}
				reader.readAsArrayBuffer(noise_file);
			});
		}
		
		else {
			setTimeout(function(){
				checkSpeechFile();
			},250);
		}
	}
}
setTimeout(init, 100); //Do something about this later

function start() {
	snab = cutNoise(nab.getChannelData(0), sab.getChannelData(0).length);
	var mixed = mix(sab.getChannelData(0), snab.getChannelData(0));
	initVars();
	speechSpectrum = transform(sab.getChannelData(0))["spectrum"];
	var tmap = transform(snab.getChannelData(0));
	noiseReal = tmap["real"];
	noiseImag = tmap["imag"];
	canvas.style.display = "none";	//Don't display the canvas yet
	draw(speechSpectrum);
    initBlur();
    enableStage();
}

//Intializes variables for the round
function initVars(){
	var width = Math.ceil(sab.getChannelData(0).length/HOP); 
	//set html canvas variables:
	canvas.width = width;
	canvas.height = SAMPLES/2 - clipY;
	total = width * (SAMPLES/2 - clipY);
	console.log("canvas is " + canvas.width + " by " + canvas.height);
	locationsUnblurred = new Set(); //Resets the unblurred locations to blurred
}

var messages = {
	'loading' : "Loading Files...",
    'playing': "Playing Back Audio...",
   	'prompt' : "Adjust your volume (the playback will be loud) and test the audio by removing the blur."
   				+ " Try to reveal the speech spectrogram under the blur. When you're ready to start playing press the continue button."
}


//plays sample buffer and updates the round status
function play(buf) {
	disableStage();
    // Create a source node from the buffer
    source = context.createBufferSource();
    source.buffer = buf;
    // Connect to the final output node (the speakers)
    source.connect(context.destination);
    // Play immediately
    source.start(0);
	disableStage();
		
	source.onended = function () {
		enableStage();
	}
}
