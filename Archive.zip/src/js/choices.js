//Script for displaying the choices.
var choices = null;
var div = document.getElementById('choices');
var btns = [];
var correctChoice;
var answered_yet;
var answered_correctly;
var b;
var wordGuessed;

//Waits for choices to be filled, shuffles choices and adds them to the DOM 
function initChoices(){
	if(choices){
		correctChoice = choices[0];	//Correct choice is the first one
		shuffle(choices);
		document.getElementById('choices').innerHTML = "";
		btns = [];
		for(var i = 0;i<choices.length;i++){
			btns.push(new button(choices[i], i));
		}
		b = document.getElementsByClassName("button btn btn-choice");
		answered_yet = false;
		disableButtons();
	}
}


//Shuffles elements of an array
function shuffle(a) {
    var j, x, i;
    for (i = a.length; i; i -= 1) {
        j = Math.floor(Math.random() * i);
        x = a[i - 1];
        a[i - 1] = a[j];
        a[j] = x;
    }
}

//Sets the color of the buttons. Should be called after any button is pressed
function updateColor (){
	for(var i = 0;i < btns.length; i ++){
		b[i].style.background = b[i].value == correctChoice? "green": "red";
	}	
}

//Enables all of the buttons
function enableButtons (){
	for(var i = 0;i < btns.length; i ++){
		b[i].className = "button btn btn-choice enable";
	}	
}

//Disables all of the buttons
function disableButtons (){
	for(var i = 0;i < btns.length; i ++){
		b[i].className = "button btn btn-choice disabled";
	}	
}

/*********************************************
* Class to construct buttons for the choices * 
**********************************************/
class button{
	constructor(string, i){
		var btn = document.createElement("a");        
		btn.href = "#stage";
		btn.className = "button btn btn-choice";
        var t = document.createTextNode(string);
		btn.appendChild(t); 
		btn.value = string;
		
		//Handler called when user clicks a button
		btn.onclick = function(){
			updateColor();		//Correct answer is green. Incorrect answers are red.
			disableButtons();
			wordGuessed =  btn.value;
			answered_yet = true;
			answered_correctly = btn.value == correctChoice ? true : false;
			roundEnd();
		};

		div.appendChild(btn);
	}	
}
