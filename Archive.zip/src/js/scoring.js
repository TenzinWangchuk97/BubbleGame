/*
The variables and functions of the auditory bubbles scoring system. In simplest terms
the user can see his remaining bubble points and his total score. When the user selects 
an answer, the bubble points will either be negatively or positiviely or added to the 
total score depending on their choice. However, scoring is not entirely based on the 
users choice.

						Rules For The Scoring Weighing System
------------------------------------------------------------------------------------------
1. The deduction and rewarding scores will be scaled by the number of times the user blurs 
	-This will prevent rewarding consistent small removals
	-The user will be rewarded more bubble points for blurring less
	-If the user chooses the incorrect answer, but unblurred a considerate amount of times,
	 they will be deducted less harshly than a user who blatantly guesses without removing

2. When blurs the same location twice they will be penalized
	-Playing the audio file over and over without penality should not be allowed
------------------------------------------------------------------------------------------	
*/

var max_deduction;		//Stores the maximum amount of points than can be deducted
var bubble_points;		//Stores the amount of bubble points for each round
var total_score = 0;	//Stores the total score for the entire game loop
var score_scale;		//The amount removed will be divided by this value in the scoring process
var rewarding_score;	//The amount that gets added to the bubble_points 
var deduction_score;	//The amount that gets added to the bubble_points
var round_continue;		//Stores whether or not round is being continued 
var total_removed;
var pointsScored;

//Initialize variables for scoring
function initScoring() {
	max_deduction = 5;
	answered_yet = false;
	bubble_points = 100;
    score_scale = 90;	
	rewarding_score = 100;	
	deduction_score = 150;	
	total_removed = 0;
	updateScore(0);
}

//Update the score on the main page. The current score is added to the total score.
function updateScore() {
	//When the user scores, the potential score cannot change until the next round
	if(stage_enabled) {	//The user can still blur locations
		if(is_drawing) {	//Called when user blurs out any location
		
			if(amount_removed < 100)		
				bubble_points -= 8;		//If player clicks the around the same spot twice, they will be penalized
			
			else {
				if(mouse_dragging) bubble_points -= Math.min(parseInt(amount_removed / score_scale), 100); 
				
				else
					bubble_points -= Math.min(parseInt(amount_removed / score_scale), max_deduction); 
			}
						
			total_removed += amount_removed;
			amount_removed = 0; //Resets amount_removed for next click
		}
	}

	if(answered_yet == true){	 
		
		if(answered_correctly == true) {	//Answered correctly
			answerRight();
		}
		
		else if(answered_correctly == false) {
			answerWrong();
		}

		total_score += bubble_points	
		disableStage();
		pointsScored = parseInt(bubble_points); 
		bubble_points = 0;
	}

	checkBubblePoints();
	updateScoreBoard();
}

function answerRight() {
	bubble_points += rewarding_score;
	bubble_points = parseInt( Math.max( 0, bubble_points - Math.pow(total_removed, 1/2.3)));
}

function answerWrong() {
	bubble_points += parseInt( deduction_score + Math.pow(total_removed, 1/3) );
	bubble_points *= -1;
}

//This functions checks to see if bubble_points is below zero, if so they cannot remove anymore
function checkBubblePoints() {
	if(bubble_points <= 0) {
		disableStage();
		bubble_points = 0;
		return true;
	}
	else return false;
}

function updateScoreBoard() { 	//Update the scoreboard on the html page
	document.getElementById("bubble_points").innerHTML = bubble_points;
	document.getElementById("total_score").innerHTML = total_score;	
}