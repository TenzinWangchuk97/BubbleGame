/*
FUNCTIONS FOR BLUR:
*/

var canvas = document.getElementById("canvas");	//Stores the DOM canvas 
var domStage = document.getElementById("stage");
var stage;				//Easel stage
var drawing_canvas;		//Easel drawing canvas
var blur;				//Easel blur
var cursor;				//The stage cursor represented by a white ellipse
var image;				//Stores the image of spectrogram on canvas
var bitmap;				//Easel bitmap 
var maskFilter;			//Easel alpha mask filter
var is_drawing; 		//boolean value for whether or not blur is drawing
var radius = 15; 		//radius of the cursor(ellipse)
var scale;				//keeps track of the scale of the cursor along the y-axis
var clipY = 200;		//How far down the spectrogram is moved downwards
var can_draw = false;   //boolean value for whether or not image can be blurred
var can_deduct;			//boolean value for whether or not bubble_points can be deducted
var copy_image;
var click_positions;
var stretch_scale;
var dragSet;
var mouse_dragging = false;
var stage_enabled = false;

function initBlur(remove) {
	stage = new createjs.Stage("canvas");
    image = new Image();
	image.src = canvas.toDataURL();
	stretch_scale = domStage.offsetWidth * 0.9 / canvas.width;
    image.onload = function (){ handleComplete(remove)};
	dragSet = new Array();
    click_positions = new Array();
}

//Initiates the stage, cursor and the blur
function handleComplete(remove) {
    stage.enableMouseOver();
    stage.addEventListener("stagemousemove", handleMouseMove);
    stage.addEventListener("stagemousedown", handleMouseDown);
    stage.addEventListener("stagemouseup", handleMouseUp);

    console.log("canvas is " + canvas.height + " by " + canvas.width);

    drawing_canvas = new createjs.Shape();
    
    bitmap = new createjs.Bitmap(image);
    copy_image =  new createjs.Bitmap(image);
	
	blur = new createjs.Bitmap(image);
	blur.filters = [new createjs.BlurFilter(30, 30, 30), new createjs.ColorMatrixFilter(new createjs.ColorMatrix().adjustSaturation(-100))];
    
  	canvas.width *= stretch_scale;
  	domStage.scaleX = domStage.scaleX*0.9/stretch_scale;
    bitmap.scaleX = blur.scaleX = copy_image.scaleX = stretch_scale;

    blur.cache(0, 0, canvas.width, canvas.height);

    stage.addChild(blur, bitmap);
    updateCacheImage(false);
 	
    cursor = new createjs.Shape(new createjs.Graphics().beginFill("#FFFFFF").drawCircle(0, 0, radius));
    cursor.cursor = "pointer";
  
    stage.addChild(cursor);
    stage.update();
    
	canvas.style.display = "initial";
	focusStage();

    if (remove){
        removeBlur();
        drawClickPos();
    }
    else{
        console.log("blur");
    }


}

//Updates the size of the cursor based on the position of the mouse
function handleMouseMove(event) {
	cursor.x = stage.mouseX;
	cursor.y = stage.mouseY;
	scale = (stage.mouseY - canvas.height*2)/canvas.height;
	cursor.scaleY = scale;
	
	if(!is_drawing) {
		stage.update();
	}

	else if(stage_enabled) {
		is_drawing = true;
		mouse_dragging = true;
		updateBlur();
	}
}

function handleMouseDown(event) {
	if(stage_enabled) {
		cursor.visible = false;	//Hides the cursor when blur is removed
		is_drawing = true;
		updateBlur();
	}
}

//Removes the blur and updates noise and score
function handleMouseUp(event) {
	if(stage_enabled && is_drawing) {
		mixAndPlay();
		updateScore();
		bufferStage();
		dragSet = new Array();
	}
	is_drawing = false;
	mouse_dragging = false;
}

function updateBlur() {
	disableButtons();

	var midPoint = new createjs.Point(stage.mouseX, stage.mouseY);
    drawing_canvas.graphics.setStrokeStyle(1, "round", "round")
	  .beginFill("rgba(0,0,0,1)")
	  .drawEllipse((stage.mouseX-radius)/stretch_scale, stage.mouseY - radius*scale, radius*2/stretch_scale, radius*2*scale); 

	var centerX = parseInt(stage.mouseX/stretch_scale), centerY = parseInt(stage.mouseY+clipY), xRadius = radius, yRadius = parseInt(radius*scale*-1);
 	var str = centerX.toString() + ", " + centerY.toString() + ", " + xRadius.toString() + ", " + yRadius.toString();
	console.log(str);
 	if(!click_positions.includes(str)) {
		click_positions.push(str);	
		pushDragSet(centerX, centerY, xRadius, yRadius);
	}

	updateCacheImage(true);
}

function removeBlur() {	//Removes blur
	stage.removeAllChildren();
	stage.removeAllEventListeners()
	stage.addChild(copy_image);
	stage.update();
}

function updateCacheImage(update) {	//Updates the blur
	if (update) {
	  drawing_canvas.updateCache();
	} 
	
	else {
		drawing_canvas.cache(0, 0, image.width, image.height);
	}

	maskFilter = new createjs.AlphaMaskFilter(drawing_canvas.cacheCanvas);

	bitmap.filters = [maskFilter];
    if (update) {
	 	  bitmap.updateCache(0, 0, image.width, image.height);
	} 
	
	else {
		bitmap.cache(0, 0, image.width, image.height);
	}
 	stage.update();
}

function mixAndPlay() {
	var centerX = parseInt(stage.mouseX), centerY = parseInt(stage.mouseY+clipY), xRadius = radius, yRadius = parseInt(radius*scale*-1);
	var buffer;

	if(mouse_dragging) {
		buffer = updateNoiseDrag(dragSet);
	}

	else {
		buffer = updateNoise(centerX, centerY, xRadius, yRadius);
	}

	play(buffer);
}

function pushDragSet(centerX, centerY, xRadius, yRadius) {
	clickPoint = new Set()
	clickPoint.add(centerX);
	clickPoint.add(centerY);
	clickPoint.add(xRadius);
	clickPoint.add(yRadius)
	dragSet.push(clickPoint);
}

function disableStage() {
	stage_enabled = false;
}

function enableStage() {
	if(!checkBubblePoints()) {
		stage_enabled = true;
		cursor.visible = true;
	}
}

function bufferStage() {
	if(!checkBubblePoints()) {
		disableStage();

		setTimeout(enableStage, 200);
	}
} 

function focusStage() {
	window.location.hash = '#stage';
}

function drawClickPos(){

    var arr = JSON.parse(clickPos);

    var c = document.getElementById("canvas");
    c.style.position = "relative";
    var ctx = c.getContext("2d");
    ctx.fillStyle = 'red';

    for (i=0; i<arr.length; i= i+4){
        var current = i;
        var a = current;
        var b = current + 1;
        var c = current + 2;
        var d = current + 3;

        ctx.fillRect(arr[a], arr[b] - clipY , arr[c], arr[d]);
    };

}