//variables for sound and transform
var context = new AudioContext;
const SPEECH = "speech";
const NOISE = "noise";
var SAMPLES = 1024;	
var HOP = 256;
var noiseReal, noiseImag, speechSpectrum;
var locationsUnblurred; //Stores the locations of the spectrum that are blurred out	
var random;
var amount_removed = 0;		//Tracks the amount of noise removed for each blur
var speechArrayBuffer, noiseArrayBuffer = null;

//This function fills the last elements with zeros
function fillZero(buffer){
	temp = new Float32Array(SAMPLES);
	for(var j = 0; j < buffer.length; j++){
		temp[j] = buffer[j];
	}
	for(var j = buffer.length; j < SAMPLES; j++){
		temp[j] = 0;
	}
	buffer = temp;
	return buffer;
}

function mix(speecharray, noisearray) {
    var out = context.createBuffer(1, sab.length, 44100);
    var outarray = out.getChannelData(0);
    
    for(var i = 0; i < speecharray.length; i++){
    	outarray[i] += speecharray[i] * 0.5;
    	outarray[i] += noisearray[i] * 2.5;
    }
    return out;
}

function getDeepCopy(bufferSectionShallow){
	var arr = new Float32Array(bufferSectionShallow.length);
	var toCopy = JSON.parse(JSON.stringify(bufferSectionShallow));
	for(var i = 0; i < arr.length; i++){
		arr[i] = toCopy[i];
	}
	return arr;
}

function transform(buff){
	var i = 0;

	//create the arrays that will store the results of the transforms
	var width = Math.ceil(buff.length/HOP); //width will be how many times we do the transform 
	var spectrum = new Array(width); 
	var real = new Array(width);
	var imag = new Array(width);

	while(i < buff.length){
		var bufferSectionShallow = buff.slice(i, i + SAMPLES);
		var bufferSection = getDeepCopy(bufferSectionShallow);
		if(bufferSection.length < SAMPLES) { bufferSection = fillZero(bufferSection); }
		bufferSection = windowSamples(bufferSection);
		var fft = new FFT(SAMPLES, 44100);

		fft.forward(bufferSection);

    	spectrum[i/HOP] = DSP.mag2db(fft.spectrum);
				
		real[i/HOP] = fft.real;
		imag[i/HOP] = fft.imag;
	
     	i+=HOP; //increment i so we can get the next slice
	}

	return {"real" : real, "imag" : imag, "spectrum" : spectrum};
}

function inverseTransform(real, imag, length){
	var newArray = new Float32Array(length);
	var temp, start = 0;
	var fft = new FFT(SAMPLES, 44100);
	for(var i = 0; i < real.length; i++){
		temp = fft.inverse(real[i], imag[i]); //this stores the result of the fft in a float32array of size samples. 	
		temp = windowSamples(temp);
		for(var j = 0; j < temp.length; j++){
			if(start+j < newArray.length)
				newArray[start+j] += temp[j];
		}
		start +=HOP;
	}
	for(var i = 0; i < newArray.length; i++){
		newArray[i] *= 0.65; //TO STOP THE SOUND FROM GETTING LOUDER EACH TIME
	}
	return newArray;
}

function windowSamples(bufferSection){
	for (var i = 0; i < SAMPLES; i++ ){
		bufferSection[i] *= ( 0.5 * ( 1 - Math.cos( (2 * Math.PI * i )/(SAMPLES-1) ) ) );
	} 
	return bufferSection;
}

function draw(spectrum){
	var width = spectrum.length;
	var height = spectrum[0].length;

	var ctx = canvas.getContext("2d");	
	var myImageData = ctx.createImageData(width, SAMPLES/2);
	var data = myImageData.data;

	//get max and min
	var min = spectrum[0][0];
	var max = spectrum[0][0];
	for(var i = 0; i < width; i++){
		for(var j = 0; j< height; j++){		
			if((spectrum[i][j])	< min){
				min = spectrum[i][j];
			}	
			else if ((spectrum[i][j]) > max){
				max = spectrum[i][j];
			}
		}
	}	
	//data is a 1D array of the image data in RGBA format.
	//Every 4 values of data correspond to one pixel 
	for(var i = 0; i < width; i++){
		for(var j = 0; j< height; j++){		
			var start = (width*j + i)*4;
			var n = spectrum[i][height - j];
			var val = (n-min)/(max-min);
			data[start] = val * 255;
			data[start+1] = val * 255;
			data[start+2] = val * 255;
			data[start+3] = 255;			
		}
	}	
    ctx.putImageData(myImageData, 0, -clipY);
}

//shortens noiseArrayBuffer to be same length of speech
function cutNoise(noise, desiredLength){
	random = Math.floor(Math.random() * (noise.length - desiredLength)); //get a random starting point for the sound
	noise = noise.slice(random, random + desiredLength);
	snab = context.createBuffer(1, sab.length, 44100); 
 	snab.copyToChannel (noise,0,0); 
 	return snab;
}

//calls functions to update noise after click
function updateNoise(centerX, centerY, xRadius, yRadius){
	removeNoise(centerX, centerY, xRadius, yRadius);
	// CALL function to do inverse transform
	var newArray = inverseTransform(noiseReal, noiseImag, sab.getChannelData(0).length);
	snab.copyToChannel(newArray,0,0); 
	var mixed = mix(sab.getChannelData(0), snab.getChannelData(0));

	setTimeout(function() {
		var tmap = transform(snab.getChannelData(0));
		noiseReal = tmap["real"];
		noiseImag = tmap["imag"];
	}, 100);
	return mixed;
}

//accepts center of where clicked and x and y radius
//sets spectrum to 0 for all points within the ellipse
function removeNoise(centerX, centerY, xRadius, yRadius){
	var maxWidth = noiseReal.length;
	var maxHeight = (noiseReal[0].length)/2;
	
	for(var x = Math.max(0,(centerX - xRadius)); x < Math.min((centerX + xRadius), maxWidth); x++){
		for(var y = Math.max(clipY,(centerY - yRadius)); y < Math.min((centerY + yRadius),maxHeight); y++){
			if( ( ((x - centerX) * (x - centerX)) / (xRadius * xRadius) ) + 
				( ((y - centerY) * (y - centerY)) / (yRadius * yRadius) ) <= 1	){
				y1 = SAMPLES/2 - y;
				noiseReal[x][y1] = 0;
				noiseReal[x][SAMPLES-y1] = 0;
				noiseImag[x][y1] = 0;
				noiseImag[x][SAMPLES-y1] = 0;
				if(!locationsUnblurred.has(y1*maxWidth + x)){
					amount_removed++;
					locationsUnblurred.add(y1*maxWidth + x);
				}
			}
		}
	}
}

function updateNoiseDrag(dragSet) {
	for(var i = 0;i < dragSet.length;i++) {
		var it = dragSet[i].values();
		var centerX = it.next().value;
		var centerY = it.next().value;
		var xRadius = it.next().value;
		var yRadius = it.next().value;
		removeNoise(centerX, centerY, xRadius, yRadius);
	}

	// CALL function to do inverse transform
    var newArray = inverseTransform(noiseReal, noiseImag, sab.getChannelData(0).length);
	snab.copyToChannel(newArray,0,0); 
	var mixed = mix(sab.getChannelData(0), snab.getChannelData(0));
	setTimeout(function() {
		var tmap = transform(snab.getChannelData(0));
		noiseReal = tmap["real"];
		noiseImag = tmap["imag"];
	}, 100);
	return mixed;
}


