//Code to convert a blob to a file begins here
var getFileBlob = function (url, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url);
    xhr.responseType = "blob";
    xhr.addEventListener('load', function() {
        cb(xhr.response);
    });
    xhr.send();
};

var blobToFile = function (blob, name) {
    blob.lastModifiedDate = new Date();
    blob.name = name;
    return blob;
};

var getSpeechObject = function(filePathOrUrl, cb) {
    getFileBlob(filePathOrUrl, function (blob) {
       cb(blobToFile(blob, speechFile));
    });
};

var getNoiseObject = function(filePathOrUrl, cb) {
    getFileBlob(filePathOrUrl, function (blob) {
       cb(blobToFile(blob, noiseFile));
    });
};
//Code to convert a blob to a file ends here

//Handles any response string 
function handleResponse(response){
	response = response.replace("{", "");
	response = response.replace("}", "");
	response = replaceAll(response, "=", " ");
	
	var split = [];
	split = response.split(", ");
		
	for(var i = 0;i < split.length;i++) {
		var message = split[i];
		var value = split[i].substring(split[i].indexOf(" ")+1, split[i].length);
		
		if(message.includes("speechFile")) speechFile = value;
		else if(message.includes("noiseFile")) noiseFile = value;
		else if (message.includes("choices")) server_choices = value;
	}
}

//Replaces all occurences in any string
function replaceAll(string, key, replacement) {
	while(string.includes(key)){
		string = string.replace(key, replacement);
	}
	return string;
}


