import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';
import Sound from 'react-sound';
import soundfile from './aXaW3/acha_w3_01_03.wav';
//import * as audio from './src/audio';

function rect(props) {
    const {ctx, x, y, width, height} = props;
    ctx.fillRect(x, y, width, height);
}

// class AudioDataContainer extends React.Component {

//   constructor(props) {
//     super(props);
//     this.state = {}
//     this.frequencyBandArray = [Array(25).keys()]
//   }

//   initializeAudioAnalyser = () => {
//     const audioFile = new Audio();
//     const audioContext = new AudioContext();
//     const source = audioContext.createMediaElementSource(audioFile);
//     const analyser = audioContext.createAnalyser();
//     audioFile.src = soundfile;
//     analyser.fftSize = 256
//     source.connect(audioContext.destination);
//     source.connect(analyser);
//     audioFile.play()
//       this.setState({
//         audioData: analyser
//       })
//   }

//   getFrequencyData = (styleAdjuster) => {
//     const bufferLength = this.state.audioData.frequencyBinCount;
//     const amplitudeArray = new Uint8Array(bufferLength);
//     this.state.audioData.getByteFrequencyData(amplitudeArray)
//     styleAdjuster(amplitudeArray)
//   }
// }

class AudioAnalyser extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    console.log(this)
  }

    initializeAudioAnalyser = () => {
      console.log("anything?")
    const audioFile = new Audio();
    const audioContext = new AudioContext();
    const source = audioContext.createMediaElementSource(audioFile);
    const analyser = audioContext.createAnalyser();
    audioFile.src = soundfile;
    analyser.fftSize = 64
    source.connect(audioContext.destination);
    source.connect(analyser);
    audioFile.play()
      this.setState({
        audioData: analyser
      })
  }

  render() {
        // return <Game initializeAudioAnalyser = {this.initializeAudioAnalyser} />;
    return <AudioVisualiser audioData={this.state.audioData} />;
  }
}

class AudioVisualiser extends React.Component {
  constructor(props) {
    super(props);
    this.canvas = React.createRef();
    console.log(this)
  }

  componentDidUpdate() {
    this.draw();
  }

  draw() {
    const { audioData } = this.props;
    const canvas = this.canvas.current;
    const height = this.canvas.height;
    const width = this. canvas.width;
    const context = this.canvas;
    let x = 0;
    var sliceWidth = (width * 1.0) / audioData.length;

    context.lineWidth = 2;
    context.strokeStyle = '#000000';
    context.clearRect(0, 0, width, height);

    context.beginPath();
    context.moveTo(0, height / 2);
    for (const item of audioData) {
      const y = (item / 255.0) * height;
      context.lineTo(x, y);
      x += sliceWidth;
    }
    context.lineTo(x, height / 2);
    context.stroke();
  }

  render() {
    this.draw();
    return (
    <canvas width="300" height="300" ref="spect" />
    );
  }
}

class Game extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      blur: true,
      board: true,
      points: 100,
      totalPoints: 0,
      choices: Array(6),
    };
  }
  //needs onclick listener
  //and also when mouse hovering over screen
  //volume = color intensity = amplitude
  //freq = y axis = (how many times (amp/time)wave up and down per sec)
  //time = x axis

  // handleClick(i) {
  // }

  // componentDidMount() {
  //   this.audioContext = new (window.AudioContext ||
  //     window.webkitAudioContext)();
  //   this.analyser = this.audioContext.createAnalyser();
  //   this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);
  //   this.source = this.audioContext.createMediaStreamSource(soundfile);
  //   this.source.connect(this.analyser);
  //   console.log(this.analyser);
  // }

  // componentDidMount() {this.updateCanvas();}
  componentDidUpdate() {this.updateCanvas();}

  controlAudio(status) {
    this.setState({
      status
    })
  }
 
  changeScheme(e) {
    this.setState({
      audioType: e.target.value
    })
  }

  updateCanvas() {
    console.log("updatedCanvas")
    const ctx = this.refs.playArea.getContext('2d');
    ctx.clearRect(0,0, 300, 300);
    // draw children “components”
    rect({ctx, x: 0, y: 0, width: 300, height: 300});
    //hidden rect on top of this rect^
    rect({ctx, x: 100, y: 100, width: 50, height: 50});
  }

  render() {
    const choices = this.choices

  /*
    //or consts?
    const AudioContext = (window.AudioContext || window.webkitAudioContext);
    var audioCtx = AudioContext.createMediaStreamSource(soundfile);
    var analyser = audioCtx.createAnalyser();

    //analyser.fftSize = 256;
    analyser.fftSize = 2048;
    //bincount=frequency =get freqdata
    //fftsize=amplitude = get bytetimedomain data

    const bufferLength = analyser.frequencyBinCount;
    //console.log(bufferLength);
    const dataArray = new Uint8Array(bufferLength);
    analyser.getByteFrequencyData(dataArray);
    //analyser.getByteTimeDomainData(dataArray);
    for(var i = 0; i < bufferLength; i++) {
          console.log(dataArray)
          var v = dataArray[i] / 128.0;
          // console.log(v);

    this.getBandFrequency = function(index) {
      console.log(this.bandwidth);
      return this.bandwidth * index + this.bandwidth / 2;
  };
  }
  */

    return (
      <div>
        <div> Bubble Points {'points #'} Total {'total #'} </div>
        <canvas ref= "playArea" width={300} height={300} />
        <AudioAnalyser audio = "http://m.mr-pc.org/bubblesGame/acha_w3_01_03.wav" />
        <Sound 
          //url= 'http://m.mr-pc.org/bubblesGame/acha_w3_01_03.wav'
          url={soundfile}
          playStatus={Sound.status.PLAYING}
          playFromPosition={0 /* in milliseconds */}
          onLoading={this.handleSongLoading}
          onPlaying={this.handleSongPlaying}
          onFinishedPlaying={this.handleSongFinishedPlaying}
        />
        <div>Which word did you hear?</div>
        <div>
          <ul>
            <button>{choices}</button>
            <button>{choices}</button>
            <button>{choices}</button>
            <button>{choices}</button>
            <button>{choices}</button>
          </ul>
        </div>
      </div>
    );
  }
}


export default Game;
